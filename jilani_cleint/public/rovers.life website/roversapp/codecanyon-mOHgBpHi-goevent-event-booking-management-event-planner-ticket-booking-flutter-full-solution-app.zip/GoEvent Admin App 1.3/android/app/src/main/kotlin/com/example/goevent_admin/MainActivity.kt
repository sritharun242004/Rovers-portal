package com.example.goevent_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
