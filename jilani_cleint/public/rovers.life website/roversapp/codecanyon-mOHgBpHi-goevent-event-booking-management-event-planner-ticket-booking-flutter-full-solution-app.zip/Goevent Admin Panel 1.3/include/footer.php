 <?php 
 include 'include/eventconfig.php';
 echo $validate['data'];
 ?>