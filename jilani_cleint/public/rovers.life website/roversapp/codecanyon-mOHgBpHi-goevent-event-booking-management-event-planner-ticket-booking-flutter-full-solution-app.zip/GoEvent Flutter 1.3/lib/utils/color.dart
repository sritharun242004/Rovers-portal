import 'package:flutter/material.dart';

Color primeryColor = Colors.white;
Color darkPrimeryColor = const Color(0xff2D2D3A);

Color cardColor = Colors.white;
Color darkcardColor = const Color(0xff3d3d4e);

Color textColor = const Color(0xff2D2D3A);
Color darktextColor = const Color(0xff5669FF);

Color proColor = const Color(0xff7e8ae0);
Color darkproColor = const Color(0xff393948);

Color text1Color = const Color(0xff2D2D3A);
Color darktext1Color = const Color(0xffDADADA);

Color whiteColor = Colors.white;
Color darkwhiteColor = Colors.black;

Color buttonsColor = const Color(0xff5669FF);
Color darkbuttonsColor = const Color(0xff5669FF);

Color buttonColor = const Color(0xff5669FF);
Color buttonboldColor = const Color(0xff2D2D3A);

Color topColor = const Color(0xff5669FF);
Color darktopColor = const Color(0xff404052);
Color darktopColor1 = const Color.fromARGB(255, 77, 77, 96);

Color darkblackColor = Colors.black;
Color blackColor = Colors.black;

Color blueColor = const Color(0xff00F8FF);
Color darkblueColor = const Color(0xff2D2D3A);

Color orangeColor = const Color(0xffd6feff);
Color darkorangeColor = const Color(0xff393948);

Color pinkColor = const Color(0xfff0f0f0);
Color darkpinkColor = const Color(0xff393948);

Color darkColor = Colors.black;
Color lightColor = Colors.white;
