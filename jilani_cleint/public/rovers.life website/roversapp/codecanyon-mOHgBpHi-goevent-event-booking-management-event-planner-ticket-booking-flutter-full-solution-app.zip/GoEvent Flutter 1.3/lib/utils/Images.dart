// ignore_for_file: file_names

class Images {
  static const calendar = "image/CalendarB.png";
  static const home = "image/HomeB.png";
  static const rectangle = "image/Love.png";
  static const search = "image/map-pin.png";
  static const user = "image/UserB.png";
  static const referAnd = "image/referandfriend.png";
  static const skeleton = "image/skeleton.gif";
  static const more = "image/More.png";
}