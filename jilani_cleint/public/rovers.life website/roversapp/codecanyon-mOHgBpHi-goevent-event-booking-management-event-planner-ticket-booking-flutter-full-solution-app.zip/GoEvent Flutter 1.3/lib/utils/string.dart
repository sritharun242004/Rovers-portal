class CustomStrings {
  static const String goevet = 'GoEvent';
  static const String onbonding1 = 'Explore Upcoming and';
  static const String onbonding2 = 'Nearby Events';
  static const String safe = 'Stay safe, be safe';
  static const String covid = 'Covid - 19 Self Health\nDeclaration';
  static const String details =
      'Enjoy your favorite dishe and a lovely your friends and family and have a great time. Food from local food trucks your friends and family and have a great time. Food from local food trucks..';
  static const String detail =
      'Enjoy your favorite dishe and a lovely your friends and \nfamily and have a great time Enjoy your favorite dishe \nand a lovely your friends and family and have a great time';
  static const String payment = 'Payment Method';
  static const String card = 'Add New Card';
  static const String apple = 'Apple Pay';
  static const String musics = 'Music';
  static const String art = 'ART';
  static const String seeall = 'See All';
  static const String upcoming = 'Upcoming Events';
  static const String trending = 'Trending Events';
  static const String food = 'FOOD';
  static const String get = 'Get \$20 for ticket';
  static const String others = 'OTHERS';
  static const String sport = 'Sport';
  static const String party = 'Party';
  static const String paypal = 'PayPal';
  static const String invites = 'Invite your friends';
  static const String google = 'Google Pay';
  static const String pay = 'Pay by Debit / Credit Card';
  static const String voucher = 'Add Voucher';
  static const String vouchers = 'Voucher';
  static const String success = 'Thank you for Upgrading!!!';
  static const String subtitle =
      ' You can continue with the package till the date we mention. Good Day.';
  static const String applied = 'APPLIED VOUCHER CODE';
  static const String event = 'EventHub21';
  static const String music = 'International Band Music Concert';
  static const String name = 'Jisan X Rahman';
  static const String date = '14 December, 2021';
  static const String location = 'Gala Convention Center';
  static const String location1 = '36 Guild Street London, UK';
  static const String time = '07:30 PM';
  static const String buy = 'BUY TICKET ';
  static const String events = 'Event Details';
  static const String about = 'About Me';
  static const String interest = 'Interest';
  static const String devid = 'David Silbia';
  static const String location2 = 'Location';
  static const String follow = 'Follow';
  static const String msg = 'Message';
  static const String buymoreticket = 'Buy More Ticket';
  static const String invite = 'INVITE';
  static const String finvite = 'Invite Friend';
  static const String find = 'Find Conversation';
  static const String zenifero = 'Zenifero Bolex';
  static const String angelina = 'Angelina Zolly';
  static const String feb = '10 Feb';
  static const String call = 'Call';
  static const String doit = 'Okay, I will do it tonight!';
  static const String yeah =
      'Yeah I am ready to start! Please send me the required files and also please invite me on the campaign.';
  static const String awesome = 'Awesome, You are ready now?';
  static const String thanks =
      'Hi, Thanks for your message. The answer is yes!';
  static const String search = 'Search';
  static const String ever =
      'With the variability and ever-changing landscape of \nsocial media, there’s value in reaching our audience\nwhere they are most likely to see and read our messages.\nWith the variability and ever-changing landscape of \nsocial media, there’s value in reaching our audience\nwhere they are most likely to see and read our messages.\nThat’s why we text,”  \nsocial media, there’s value in reaching our audience';
  static const String dire = 'Directions';
  static const String ticket = 'My Ticket';
  static const String review =
      'Cinemas is the ultimate experience to see \nnew movies in Gold Class or Vmax. Find a \ncinema near you.';
  static const String rocks = 'Rocks Velkeinjen';
  static const String fname = 'Full name';
  static const String birth = 'Date of Birth';
  static const String notification = 'Notification';
  static const String notificationdetails =
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor';
  static const String no = 'No Notifications!';
  static const String w1 = 'Lorem ipsum dolor sit amet, consectetur';
  static const String w2 = 'adipiscing elit sed do eiusmod tempor';
  static const String working = 'We’re working on 24X7';
  static const String readmore =
      'Enjoy your favorite dishe and a lovely your friends and family and have a great time. Food from local food trucks will be available for purchase.';
}
